# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.5](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-offers-notification@1.0.4...@ecomplus/widget-offers-notification@1.0.5) (2020-12-16)

**Note:** Version bump only for package @ecomplus/widget-offers-notification





## [1.0.4](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-offers-notification@1.0.3...@ecomplus/widget-offers-notification@1.0.4) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-offers-notification





## [1.0.3](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-offers-notification@1.0.2...@ecomplus/widget-offers-notification@1.0.3) (2020-12-15)

**Note:** Version bump only for package @ecomplus/widget-offers-notification





## [1.0.2](https://github.com/ecomplus/storefront/compare/@ecomplus/widget-offers-notification@1.0.1...@ecomplus/widget-offers-notification@1.0.2) (2020-10-26)

**Note:** Version bump only for package @ecomplus/widget-offers-notification





## 1.0.1 (2020-06-18)

**Note:** Version bump only for package @ecomplus/widget-offers-notification
